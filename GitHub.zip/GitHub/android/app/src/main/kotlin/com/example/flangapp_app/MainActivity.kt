package com.example.flangapp_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
